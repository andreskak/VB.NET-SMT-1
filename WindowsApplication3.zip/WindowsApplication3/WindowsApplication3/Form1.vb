﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub slide_Click(sender As Object, e As EventArgs)

    End Sub



    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click
        Me.Close()
    End Sub

    Private Sub BunifuFlatButton2_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton2.Click
        BunifuPages1.SetPage("transaksi")
    End Sub

    Private Sub BunifuFlatButton1_Click(sender As Object, e As EventArgs) Handles BunifuFlatButton1.Click
        BunifuPages1.SetPage("MENU")
    End Sub

    Private Sub menupage2_Click(sender As Object, e As EventArgs) Handles menupage2.Click

    End Sub


    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub sidemenu_Paint(sender As Object, e As PaintEventArgs) Handles sidemenu.Paint

    End Sub
End Class
